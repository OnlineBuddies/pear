sqldrop SCHEMA - Produces the DROP, DELETE, etc. commands to delete
SCHEMA (but doesn't actually modify anything).  It's the equivalent of
"sqldiff SCHEMA /dev/null".
