<?php
/**
 * Copyright Â© 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

/**
 * Bareword type tokens
 */
interface Modyllic_Token_Bareword { }
