migrate DSN SCHEMA - Make the live database at DSN look like the one
described by SCHEMA.  You could think of it as running "sqldiff DSN
SCHEMA" and applying the diff to the live database.
