<?php
/**
 * Copyright © 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

class Modyllic_Type_SmallInt extends Modyllic_Type_Integer {
    public $bytes_of_storage = 2;
    public $default_length = 6;
}

