cat FILENAME.sql | sqlcolorize - Useful for debugging, just pipe some
SQL to it on STDIN and it will put a colorized, syntax-highlighted
version on STDOUT.
