<?php
/**
 * Copyright © 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

/**
 * Indicates that we found a command delimiter (; by default)
 */
class Modyllic_Token_Delim extends Modyllic_Token_SOC {}
