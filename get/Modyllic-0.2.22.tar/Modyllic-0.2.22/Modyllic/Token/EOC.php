<?php
/**
 * Copyright © 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

/**
 * End of command-- tokens of this class mark the end of an SQL command.
 */
class Modyllic_Token_EOC extends Modyllic_Token_Except {}
