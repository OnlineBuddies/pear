<?php
/**
 * Copyright © 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

/**
 * Indicates that we've hit the end of the string that we're parsing
 */
class Modyllic_Token_EOF extends Modyllic_Token_EOC {}
