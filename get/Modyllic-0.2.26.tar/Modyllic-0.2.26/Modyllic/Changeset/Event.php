<?php
/**
 * Copyright © 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

class Modyllic_Changeset_Event extends Modyllic_Diffable {
    public $name;
    public $schedule;
    public $preserve;
    public $status;
    public $body;
}
