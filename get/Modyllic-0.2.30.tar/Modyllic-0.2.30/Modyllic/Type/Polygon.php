<?php
/**
 * Copyright © 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author astewart@online-buddies.com
 */

class Modyllic_Type_Polygon extends Modyllic_Type_Geometry { }
