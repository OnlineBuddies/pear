Finish type tests
Token object tests
Interaction between token objects and type objects, eg, normalization
Schema object tests
Schema loader tests
Diff object tests
Schema diff generation tests
Tests for various generators
Commandline class tests

