<?php
/**
 * Copyright © 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

/**
 * Reserved words
 */
class Modyllic_Token_Reserved extends Modyllic_Token_Ident { }
