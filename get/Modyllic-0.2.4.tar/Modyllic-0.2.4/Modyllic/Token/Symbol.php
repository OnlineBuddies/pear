<?php
/**
 * Copyright © 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

/**
 * Things that look like symbols
 */
class Modyllic_Token_Symbol extends Modyllic_Token { }
