<?php
/**
 * Copyright © 2013 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

/**
 * Bareword type tokens
 */
interface Modyllic_Token_Ident {
    function is_ident();
}
