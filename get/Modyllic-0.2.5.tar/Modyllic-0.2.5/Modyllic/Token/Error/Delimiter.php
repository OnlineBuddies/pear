<?php
/**
 * Copyright © 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

class Modyllic_Token_Error_Delimiter extends Modyllic_Token_Error {
    function value() {
        return "Invalid delimiter declaration";
    }
}
