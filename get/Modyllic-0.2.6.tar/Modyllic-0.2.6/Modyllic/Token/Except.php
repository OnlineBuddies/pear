<?php
/**
 * Copyright © 2012 Online Buddies, Inc. - All Rights Reserved
 *
 * @package Modyllic
 * @author bturner@online-buddies.com
 */

/**
 * Exception tokens, not generated directly.  These are various non-token
 * results.
 */
class Modyllic_Token_Except extends Modyllic_Token {}
